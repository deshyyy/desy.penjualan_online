<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Penjualan Online</title>
</head>
<body>
    <h4>Selamat Datang Di </h4><br>
    <h1>TOKO PAIKAN MUSLIM BERKAH MAKMUR </h1><br>
    <nav>
        <ul>
            <li><a href="barang/data-barang.php">Data Barang</a></li>
            <li><a href="transaksi/data-transaksi.php">Data Transaksi</a></li>
        </ul>

</body>
</html>