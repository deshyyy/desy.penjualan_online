<?php 
include("../koneksi.php");

$sql = "SELECT * FROM transaksi";
$query = mysqli_query($db, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi</title>
</head>
<body>
    <h1>Tambah Transaksi</h1>
    <header>
        <h3>Form Tambah Transaksi</h3>
    </header>
    <form action="proses-tambah-transaksi.php" method="post">
        <fieldset>
            <p>
                <label for="kode_trx">Kode Transaksi :</label>
                <input type="number" name="kode_trx" />
            </p>
            <p>
                <label for="kode">Kode Barang :</label>
                <select name="kode_brg" id="kode_brg">
                    <option value="" disabled selected> --- pilih barang --- </option>
                    <?php
                    while($barang= mysqli_fetch_array($query)){
                        echo "<option value=".$barang['kode_brg']
                            ." data-nama = ".$barang['nama_brg']
                            ." data-hrg = ".$barang['harga'].">"
                            .$barang['kode_brg']." - " .$barang['nama_brg']
                            ."</option>";
                    }
                    ?>
                </select>
            </p>
            <p>
                <label for="nama-brg">Nama Barang:</label>
                <input type="text" name="nama-brg" id="nama-brg" readonly />
            </p>
            <p>
                <label for="harga-brg">Harga Barang :</label>
                <input type="number" name="harga-brg" id="harga-brg" readonly/>
            </p>
            <p>
                <label for="jmlh-brg">Jumlah Pembelian Barang :</label>
                <input type="number" name="jmlh-brg" id="jmlh-brg" placeholder="Jumlah Transaksi" />
            </p>
            <p>
                <label for="tot-hrg">Total Bayar :</label>
                <input type="number" name="tot-hrg" id="tot-hrg" readonly />
            </p>
            <p>
                <label for="tgl-trx">Tanggal Transaksi :</label>
                <input type="date" name="tgl-trx" placeholder="tgl-trx" />
            </p>
            <p>
                <input type="submit" value="Tambah " name="tambah">
            </p>
        </fieldset>
    </form>
</body>
</html>

<script>
    document.querySelector('select').addEventListener('change', function(){
        const selectedOpt = this.options[this.selectedIndex];
        document.getElementById('nama-brg').value = selectedOpt.dataset.nama;
        document.getElementById('harga-brg').value = selectedOpt.dataset.hrg;
    })
    document.querySelector('input[name="jmlh-brg"]').addEventListener('change', function(){
        const harga = document.getElementById('harga-brg').value;
        const jmlh = this.value;
        const total_harga = harga * jmlh;
        document.querySelector('input[name="tot-hrg"]').value = total_harga;
    })
</script>