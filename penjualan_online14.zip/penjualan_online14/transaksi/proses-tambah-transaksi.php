<?php
include("../koneksi.php");

if(isset($_POST['tambah'])){

    $kodetrx = $_POST['kode-trx'];
    $kodebrg = $_POST['kode-brg'];
    $namabrg = $_POST['nama-brg'];
    $hargabrg = $_POST['harga-brg'];
    $jumlah = $_POST['jmlh-brg'];
    $tothrg = $_POST['tot-bayar'];
    $tgl = $_POST['tgl-trx'];

    $sql = "INSERT INTO transaksi (kode_transaksi, kode_brg, nama_brg, harga, jumlah, total_bayar, tanggal)
        VALUE ('$kodetrx', '$kodebrg', '$namabrg', '$hargabrg', '$jumlah', '$tothrg', '$tgl')";
    $query = mysqli_query($db, $sql);
    
    if($query){
        header('Location: data-transaksi.php?status=sukses');
    }else{
        header('Location: data-transaksi.php?statu=gagal');
    }
}else{
    die("Akses dilarang...!");
}
?>